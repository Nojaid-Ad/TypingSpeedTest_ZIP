package typingspeedtest;

import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;

public class TypingSpeedTest {

    public static void main(String[] args) {
      

        new BaseFrame();

    }

}
