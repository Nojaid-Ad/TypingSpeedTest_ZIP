package typingspeedtest;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Info extends JFrame {

    private JLabel infoLabel(JPanel containerPanel, String txt, int fontType, int fontSize) {
        JLabel label = new JLabel(txt);
        label.setForeground(StaticValues.foregroundColor);
        label.setFont(myFont(fontType, fontSize));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        containerPanel.add(label);
        return label;
    }
    JPanel body;
    JPanel buttomPanel;
    JPanel appBar;

    public Font myFont(int fontType, int fontSize) {
        return new Font("Segoe UI", fontType, fontSize);
    }

    private void initUi() {
        getContentPane().setBackground(StaticValues.backgroundColor);
        setTitle("Information Screen");
        setLayout(new BorderLayout(32, 200));

        appBar = new JPanel();
        body = new JPanel();
        buttomPanel = new JPanel();

        add(appBar, BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
        add(buttomPanel, BorderLayout.SOUTH);

        appBar.setBackground(StaticValues.backgroundColor);
        body.setBackground(StaticValues.backgroundColor);
        buttomPanel.setBackground(StaticValues.backgroundColor);

        infoLabel(appBar, "Information and Advice about this App", Font.BOLD, 22);

        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));

        infoLabel(body, "Press F5 or Enter to start the typing test or press start button", Font.PLAIN, 18);
        body.add(StaticValues.spacer("  "));

        infoLabel(body, "For best results, use a keyboard you're familiar with and ensure your hands are in a natural position", Font.PLAIN, 18);
        body.add(StaticValues.spacer("  "));

        infoLabel(body, "The more you use this app, the faster and more accurate your typing will become", Font.PLAIN, 18);

        buttomPanel.setLayout(new BoxLayout(buttomPanel, BoxLayout.Y_AXIS));

        infoLabel(buttomPanel, "Developed by Nojaid Abdullah Essa", Font.PLAIN, 12);
        infoLabel(buttomPanel, "All rights reserved ©2025", Font.PLAIN, 12);

    }

    public Info() {
        setSize(StaticValues.SCREEN_WIDTH, StaticValues.SCREEN_HEIGHT);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
        setIconImage(StaticValues.appLogo.getImage());

        initUi();

        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new BaseFrame();
                dispose();
            }
        });
    }
}
