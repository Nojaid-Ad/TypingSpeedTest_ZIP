package typingspeedtest;

import java.util.Random;

public class TextGenerator {

    private static final String[] words = {
        "Nojaid",
        "cat", "dog", "book", "car", "tree", "sun", "ball", "run", "walk", "jump",
        "speed", "game", "type", "test", "fast", "time", "start", "score", "goal",
        "easy", "play", "fun", "word", "note", "pen", "input", "line", "check", "press",
        "focus", "ready", "help", "idea", "plan", "train", "watch", "write", "task",
        "learn", "repeat", "habit", "think", "clear", "move", "click", "enter", "light",
        "track", "flow", "fix", "stop", "begin", "end", "read",
        "touch", "sound", "view", "open", "close", "blue", "green", "red", "up", "down",
        "keyboard", "typing", "practice", "accuracy", "words", "challenge", "improve",
        "skill", "quick", "minute", "record", "restart", "correct", "mistake", "result",
        "session", "target", "motion", "response", "monitor", "letter", "paragraph",
        "layout", "button", "feedback", "highlight", "match", "speedy", "performance",
        "energy", "focuses", "brain", "control", "effort", "exercise", "fingers",
        "index", "journey", "knowledge", "limit", "observe", "progress", "quality",
        "rhythm", "strategy", "understand", "velocity", "zone", "ability",
        "achievement", "attention", "balance", "clarity", "decision", "efficiency",
        "learning", "mind", "option", "precision", "quiet", "routine", "tempo",
        "thought", "vision"
    };

    public static String generate(int wordCount) {
        StringBuilder builder = new StringBuilder();
        Random random = new Random();
        for (int x = 0; x < wordCount; x++) {
            String word = words[random.nextInt(words.length)];
            builder.append(word).append(" ");
        }
        return builder.toString().trim();
    }

}
