package typingspeedtest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import java.awt.Font;
import java.awt.Insets;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;

public class BaseFrame extends JFrame {

    public boolean isStarted = false;
    private String targetText;
    private int time = 60, wpm = 0;
    private float accuracy = 0;
    private Timer timerCounter;

    private ImageIcon getIconPath(String path) {
        return new ImageIcon(BaseFrame.class.getResource(path));
    }

    public Font myFont(int fontType, int fontSize) {
        return new Font("Segoe UI", fontType, fontSize);
    }
    JTextPane textPane;
    JLabel toggleThemesIcon;
    JLabel infoLabel;
    ImageIcon themeIcon = getIconPath(StaticValues.isDarkMode ? "/images/D.png" : "/images/L.png");
    JPanel mainPanel;
    JPanel appBarPanel;

    JLabel start = new JLabel("Start");
    ImageIcon stateIcon = getIconPath("/images/start.png");

    JPanel buttomBarPanel;
    JPanel bodyPanel;
    JPanel statusPanel;

    JTextField inputField;
    JLabel wpmLapel;
    JLabel timerLabel;
    JLabel accuracyLabel;

    int correctCount = 0;
    int totalTyped;

    private void changeTheme(boolean changeMode) {

        if (changeMode) {
            StaticValues.isDarkMode = !StaticValues.isDarkMode;
            new BaseFrame();
            this.dispose();

        }

        StaticValues.toggleTheme();
        themeIcon = getIconPath(StaticValues.isDarkMode ? "/images/D.png" : "/images/L.png");
        toggleThemesIcon.setIcon(themeIcon);

    }

    private void restartTest() {
        inputField.setText("");
        wpmLapel.setText(": " + wpm);
        timerLabel.setText(": " + time);
        accuracyLabel.setText(": " + accuracy);
        isStarted = false;
        time = 60;
    }

    private void endTest() {
        inputField.setEnabled(false);

    }

    private void updateTextPane() {
        String userInput = inputField.getText();
        StyledDocument doc = textPane.getStyledDocument();
        textPane.setText("");

        StyleContext context = new StyleContext();
        Style correct = context.addStyle("Correct", null);
        Style wrong = context.addStyle("Wrong", null);
        Style normal = context.addStyle("Normal", null);

        StyleConstants.setForeground(correct, new Color(0xff4caf50));
        StyleConstants.setForeground(wrong, Color.red);
        StyleConstants.setForeground(normal, StaticValues.foregroundColor);
        correctCount = 0;
        totalTyped = userInput.length();

        for (int i = 0; i < targetText.length(); i++) {
            Style style;
            if (i < userInput.length()) {
                char userChar = userInput.charAt(i);
                char actualChar = targetText.charAt(i);
                if (userChar == actualChar) {
                    correctCount++;
                    style = correct;
                } else {
                    style = wrong;
                }
            } else {
                style = normal;
            }
            try {
                doc.insertString(doc.getLength(), String.valueOf(targetText.charAt(i)), style);
            } catch (BadLocationException ex) {
                System.out.println(ex.getMessage());
            }
        }

        textPane.setCaretPosition(0);
    }

    private void handleTyping() {
        if (!isStarted) {
            isStarted = true;
            startTimer();
            start.setEnabled(false);
            timerCounter.start();
        }
        updateTextPane();
    }

    private void startTimer() {
        wpm = 0;
        accuracy = 0;
        StyledDocument doc1 = textPane.getStyledDocument();
        SimpleAttributeSet left = new SimpleAttributeSet();
        StyleConstants.setAlignment(left, StyleConstants.ALIGN_LEFT);
        StyleConstants.setFontSize(left, 28);
        doc1.setParagraphAttributes(0, doc1.getLength(), left, false);
        textPane.setText("");
        targetText = TextGenerator.generate(250);
        isStarted = true;
        inputField.requestFocusInWindow();

        inputField.setEnabled(true);
        timerCounter = new Timer(1000, e -> {
            time--;

            timerLabel.setText(":  " + time);
            if (time < 10) {
                timerLabel.setForeground(Color.red);
            }
            if (time <= 0) {
                keyClip.stop();
                start.setEnabled(true);

                inputField.setText("");
                inputField.setEnabled(false);
                isStarted = false;
                targetText = "\n\n\t   WPM: " + wpm + " | Accuracy: " + (int) accuracy + "%\nPress start button or press (Enter - F5) to restart";
                StyledDocument doc2 = textPane.getStyledDocument();
                SimpleAttributeSet center = new SimpleAttributeSet();
                StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
                StyleConstants.setFontSize(center, 18);
                doc2.setParagraphAttributes(0, doc2.getLength(), center, false);
                textPane.setText(targetText);
                timerCounter.stop();
                time = 60;
                timerLabel.setText("Time Finish");
                timerLabel.setForeground(Color.white);
            }

        });
        updateTextPane();

    }

    private void scoreCounter() {
        int correctChars = 0;
        String input = inputField.getText();
        for (int i = 0; i < Math.min(input.length(), targetText.length()); i++) {
            if (input.charAt(i) == targetText.charAt(i)) {
                correctChars++;
            }
        }

        if (60 - time != 0) {
            wpm = (correctChars / 5) * 60 / (60 - time);
        }

        wpmLapel.setText(": " + wpm);
        accuracy = totalTyped > 0 ? (correctCount * 100f / totalTyped) : 0f;
        accuracyLabel.setText(": " + (int) accuracy + "%");

    }

    private void statusBar() {

        ImageIcon icons[] = {getIconPath("/images/wpm.png"), getIconPath("/images/timer.png"), getIconPath("/images/acc.png")};
        statusPanel = new JPanel();
        statusPanel.setBackground(StaticValues.titleBackgroundColor);
        statusPanel.add(StaticValues.spacer("           "));

        wpmLapel = new JLabel(":  " + wpm);
        wpmLapel.setFont(myFont(Font.BOLD, 14));
        wpmLapel.setForeground(Color.white);
        wpmLapel.setIcon(icons[0]);
        statusPanel.add(wpmLapel);

        statusPanel.add(StaticValues.spacer("\t  "));
        timerLabel = new JLabel(":  " + time);
        timerLabel.setFont(myFont(Font.BOLD, 14));
        timerLabel.setForeground(Color.white);
        timerLabel.setIcon(icons[1]);
        statusPanel.add(timerLabel);
        statusPanel.add(StaticValues.spacer("\t  "));

        accuracyLabel = new JLabel(":  " + accuracy + "%");
        accuracyLabel.setFont(myFont(Font.BOLD, 14));
        accuracyLabel.setForeground(Color.white);
        accuracyLabel.setIcon(icons[2]);
        statusPanel.add(accuracyLabel);

    }

    private void appBar() {

        appBarPanel = new JPanel();
        appBarPanel.setBackground(StaticValues.titleBackgroundColor);
        mainPanel.add(appBarPanel, BorderLayout.NORTH);
        appBarPanel.setLayout(new BorderLayout());
        appBarPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 75));
        toggleThemesIcon = new JLabel(" ");

        toggleThemesIcon.setIcon(themeIcon);
        toggleThemesIcon.setHorizontalTextPosition(JLabel.LEFT);

        toggleThemesIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                changeTheme(true);
            }
        });

        appBarPanel.add(toggleThemesIcon, BorderLayout.WEST);

        JLabel titleText = new JLabel("Typing Speed Test", SwingConstants.CENTER);
        titleText.setFont(myFont(Font.BOLD, 38));
        titleText.setForeground(Color.white);

        JPanel titleTextPanel = new JPanel(new BorderLayout());
        titleTextPanel.setOpaque(false);
        titleTextPanel.add(titleText, BorderLayout.CENTER);

        appBarPanel.add(titleTextPanel, BorderLayout.CENTER);

        infoLabel = new JLabel(" ");

        infoLabel.setIcon(getIconPath("/images/Info.png"));
        infoLabel.setHorizontalTextPosition(JLabel.RIGHT);

        infoLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to continure?\nThis action will close this window!", "Warning", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
                if (response == JOptionPane.OK_OPTION) {
                    dispose();
                    new Info();
                }

            }
        });

        appBarPanel.add(infoLabel, BorderLayout.EAST);
    }

    private void body() {
        bodyPanel = new JPanel();
        mainPanel.add(bodyPanel, BorderLayout.CENTER);
        bodyPanel.setLayout(new BoxLayout(bodyPanel, BoxLayout.Y_AXIS));
        bodyPanel.setBackground(StaticValues.backgroundColor);
        statusBar();

        textPane = new JTextPane();
        textPane.setEditable(false);
        textPane.setFocusable(true);
        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setBorder(null);

        scrollPane.setBackground(StaticValues.backgroundColor);
        textPane.setFont(myFont(Font.PLAIN, 28));
        textPane.setForeground(StaticValues.foregroundColor);
        textPane.setCaretColor(StaticValues.foregroundColor);
        textPane.setMargin(new Insets(0, 16, 16, 16));
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        textPane.setBackground(StaticValues.backgroundColor);
        textPane.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_F5 || e.getKeyCode() == KeyEvent.VK_ENTER) {

                    if (!isStarted) {
                        startTimer();
                        timerCounter.start();
                        start.setEnabled(false);
                        start.setIcon(stateIcon);
                        timerLabel.setText(": " + time);
                    }
                }
            }
        });
        bodyPanel.add(statusPanel);
        bodyPanel.add(scrollPane);

    }

    private void buttomBar() {
        buttomBarPanel = new JPanel();
        buttomBarPanel.setLayout(new BoxLayout(buttomBarPanel, BoxLayout.Y_AXIS));
        buttomBarPanel.setBackground(StaticValues.backgroundColor);
        mainPanel.add(buttomBarPanel, BorderLayout.SOUTH);
        buttomBarPanel.add(new JLabel("\t       "));
        start.setForeground(StaticValues.isDarkMode ? StaticValues.foregroundColor : StaticValues.primaryColor);
        start.setIcon(stateIcon);
        inputField = new JTextField();
        buttomBarPanel.add(inputField);
        inputField.setFont(myFont(Font.PLAIN, 26));
        inputField.setBackground(StaticValues.isDarkMode ? StaticValues.titleBackgroundColor : Color.white);
        inputField.setForeground(StaticValues.foregroundColor);
        inputField.setCaretColor(StaticValues.foregroundColor);

        inputField.setHorizontalAlignment(JTextField.CENTER);
        inputField.setAlignmentX(Component.CENTER_ALIGNMENT);
        inputField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                handleTyping();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                handleTyping();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
            }

        });
        inputField.addKeyListener(new KeyAdapter() {

            @Override
            public void keyPressed(KeyEvent e) {
                if (keyClip.isRunning()) {
                    keyClip.setFramePosition(0);

                }
                keyClip.setFramePosition(0);
                keyClip.start();
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    scoreCounter();
                }
            }
        });

        targetText = TextGenerator.generate(250);
        inputField.setPreferredSize(new Dimension(50, 45));
        inputField.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
        inputField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                inputField.setBorder(BorderFactory.createLineBorder(StaticValues.primaryColor, 2));

            }

            @Override
            public void focusLost(FocusEvent e) {
                inputField.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
            }
        });

        start.setAlignmentX(Component.CENTER_ALIGNMENT);

        buttomBarPanel.add(StaticValues.spacer(" "));

        buttomBarPanel.add(start);
        buttomBarPanel.add(StaticValues.spacer(" "));
        start.setFont(myFont(Font.BOLD, 22));
        start.setHorizontalTextPosition(JLabel.LEFT);
        start.setIconTextGap(4);

        start.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if (!isStarted) {
                    startTimer();
                    timerCounter.start();
                    start.setEnabled(false);
                    start.setIcon(stateIcon);
                    timerLabel.setText(": " + time);
                }

            }
        });

    }

    private void initUi() {
        this.setTitle("Main Screen");
        mainPanel = new JPanel();

        mainPanel.setLayout(new BorderLayout());
        this.add(mainPanel);
        mainPanel.setBackground(StaticValues.backgroundColor);
        appBar();
        body();

        buttomBar();

        changeTheme(false);

    }
    Clip keyClip;

    public BaseFrame() {

        try {
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(BaseFrame.class.getResource("/sounds/1.wav"));
            keyClip = AudioSystem.getClip();
            keyClip.open(audioIn);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        StaticValues.toggleTheme();
        this.setTitle("");

        this.setIconImage(StaticValues.appLogo.getImage());
        this.setSize(StaticValues.SCREEN_WIDTH, StaticValues.SCREEN_HEIGHT);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        initUi();
        this.setVisible(true);
    }
}
