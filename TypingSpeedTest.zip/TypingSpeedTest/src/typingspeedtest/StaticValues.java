package typingspeedtest;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class StaticValues {

    public static final ImageIcon appLogo = new ImageIcon(BaseFrame.class.getResource("/images/AppLogo.png"));
    public static final int SCREEN_WIDTH = 1280;
    public static final int SCREEN_HEIGHT = 720;
    public static Color backgroundColor;
    public static Color foregroundColor;
    public static Color selectedWordColor;
    public static Color titleBackgroundColor;
    public static final Color primaryColor = new Color(0x2e3d8e);

    public static boolean isDarkMode = false;

    public static JLabel spacer(String space) {
        return new JLabel(space);
    }

    public static void toggleTheme() {

        if (isDarkMode) {
            backgroundColor = new Color(0x2c2c2c);
            foregroundColor = Color.white;
            selectedWordColor = Color.blue;
            titleBackgroundColor = new Color(0xFF202020);

        } else {
            backgroundColor = new Color(0xe7e7e7);
            foregroundColor = Color.black;
            selectedWordColor = Color.cyan;
            titleBackgroundColor = primaryColor;

        }

    }

    public static void darkTheme() {

    }

}
